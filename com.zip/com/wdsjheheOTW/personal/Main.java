public class Main{
    public static void main(String[] args) {
       // GraphicsEnv graphicsEnv = new GraphicsEnv(new DrawPanel());
        Graphics graphics = new Graphics();
    }
}